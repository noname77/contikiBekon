PROCESS_NAME(testcmd_process);
PROCESS_NAME(rimeaddr_change_process);
void commands_init();

