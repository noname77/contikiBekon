#include <stdio.h>
#include "contiki.h"
#include "mc1322x.h"
#include "shell.h"
#include "commands.h"
#include "uart2_handler.h"
#include "net/rime.h"
#include "collect_my.h"
#include "multihop_my.h"

PROCESS(testcmd_process, "Test command");
SHELL_COMMAND(test_command, "test", "test: test own commands", &testcmd_process);
/* --------------------------------- */
PROCESS_THREAD(testcmd_process, ev, data) {
PROCESS_BEGIN();
  printf("Stuff works!\n\r");
PROCESS_END();
}

//uart 2 send
PROCESS(uart2_send, "uart2 send command");
SHELL_COMMAND(uart2s_command, "u2s", "u2s: send string to uart2", &uart2_send);
/* --------------------------------- */
PROCESS_THREAD(uart2_send, ev, data) {
PROCESS_BEGIN();
  printf("will be printing to uart2\r\n");
  process_post(&uart2_process, UART2_SEND, data);
PROCESS_END();
}

// change rime address (only works for 2byte long addr atm, 1 character long each (0-9))
PROCESS(rimeaddr_change_process, "Change rime address proc");
SHELL_COMMAND(rimeaddr_change, "cra", "cra: change rime address", &rimeaddr_change_process);
/* --------------------------------- */
PROCESS_THREAD(rimeaddr_change_process, ev, data) {
PROCESS_BEGIN();
  unsigned char* ptr = data;
  //set node address
  rimeaddr_t my_addr;
  my_addr.u8[0] = (*ptr++) - 48;
  my_addr.u8[1] = (*ptr) - 48;
  rimeaddr_set_node_addr(&my_addr);
  printf("Rime address changed to %d.%d\n\r", my_addr.u8[1], my_addr.u8[0]);
PROCESS_END();
}

// start collect process
PROCESS(collect_start_process, "Start collect process");
SHELL_COMMAND(collect_start, "cs", "cs: start collect process", &collect_start_process);
/* --------------------------------- */
PROCESS_THREAD(collect_start_process, ev, data) {
PROCESS_BEGIN();
  collect_init();
  printf("Collect process started\n\r");
PROCESS_END();
}

// end collect process
PROCESS(collect_end_process, "End collect process");
SHELL_COMMAND(collect_end, "ce", "ce: end collect process", &collect_end_process);
/* --------------------------------- */
PROCESS_THREAD(collect_end_process, ev, data) {
PROCESS_BEGIN();
  collect_exit();
  printf("Collect process terminated\n\r");
PROCESS_END();
}

// start multihop process
PROCESS(multihop_start_process, "Start multihop process");
SHELL_COMMAND(multihop_start, "ms", "ms: start multihop process", &multihop_start_process);
/* --------------------------------- */
PROCESS_THREAD(multihop_start_process, ev, data) {
PROCESS_BEGIN();
  multihop_init();
  printf("Multihop process started\n\r");
PROCESS_END();
}

// end multihop process
PROCESS(multihop_end_process, "End multihop process");
SHELL_COMMAND(multihop_end, "me", "me: end multihop process", &multihop_end_process);
/* --------------------------------- */
PROCESS_THREAD(multihop_end_process, ev, data) {
PROCESS_BEGIN();
  multihop_exit();
  printf("Multihop process terminated\n\r");
PROCESS_END();
}

// multihop send
PROCESS(multihop_send_process, "Multihop send process");
SHELL_COMMAND(multihop_send_cmd, "msnd", "msnd <addr> <data>: send via multihop to [addr]", &multihop_send_process);
/* --------------------------------- */
PROCESS_THREAD(multihop_send_process, ev, data) {
PROCESS_BEGIN();
  process_post(&multihop_process, mh_send, data);
  printf("Multihop send requested.\n\r");
PROCESS_END();
}


void
commands_init()
{
  // contiki commands
  shell_reboot_init();

  // own commands
  shell_register_command(&test_command);
  shell_register_command(&uart2s_command);
  shell_register_command(&rimeaddr_change);
  shell_register_command(&collect_start);
  shell_register_command(&collect_end);
  shell_register_command(&multihop_start);
  shell_register_command(&multihop_end);
  shell_register_command(&multihop_send_cmd);
}

