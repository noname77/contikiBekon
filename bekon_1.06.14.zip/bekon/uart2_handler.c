#include <stdio.h>
#include "contiki.h"
#include "mc1322x.h"
#include "contiki-uart.h"
#include "dev/leds.h"
#include "dev/serial-line.h"
#include "uart2_handler.h"

#define FLASH_LED(l) {leds_on(l); clock_delay_msec(50); leds_off(l); clock_delay_msec(50);}

// define events
process_event_t UART2_SEND;

/*---------------------------------------------------------------------------*/
PROCESS(uart2_process, "UART2 Process");
/*---------------------------------------------------------------------------*/

// handles uart2 sending and receiving
PROCESS_THREAD(uart2_process, ev, data)
{
  static struct etimer timer;

  PROCESS_BEGIN();

  static int i, j;

  leds_off(LEDS_ALL);
  UART2_SEND = process_alloc_event();

  while(1)
  {
    PROCESS_WAIT_EVENT();

    //send
    if(ev == UART2_SEND)
    {
      ("SEND\n\r");
      int cnt = 0;
      char* p = data;
      //TODO: get chars from data
      while(*p)
      {
        uart2_putc(*p++);
        cnt++;
      }
      uart2_putc('\n');
      printf("%d bytes sent to uart2\n\r", ++cnt);
    }

    //if(ev == UART2_SEND)
    /*
    int cnt = 0;
    while (uart2_can_get())
    {
      cnt++;
      char c = uart2_getc();
      
      // add to a buffer until received a line and post to all processes
      serial_line_input_byte(c, 1);
      // print to usb   
      //uart1_putc(c);
	  }
*/
    //PRINTF("\n\r%d bytes received\n\r", cnt); 
  }

  PROCESS_END();
}

/*---------------------------------------------------------------------------*/

void
uart2_handler_init()
{
  // Set UART2 to 115200 baud
	uart2_init(INC, MOD, SAMP);
  //start proces
  process_start(&uart2_process, NULL);
}

