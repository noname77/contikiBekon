#include <stdio.h>
#include "contiki.h"
#include "mc1322x.h"
#include "commands.h"
#include "uart2_handler.h"
#include "uarts_test.h"
#include "collect_my.h"
#include "settings_read.h"

PROCESS(boot_process, "Boot Process");

AUTOSTART_PROCESSES(&boot_process);

PROCESS_THREAD(boot_process, ev, data)
{
  PROCESS_BEGIN();

  printf("Stuff to be done during boot:\n\r");

  printf("initialize uart2...");
  uart2_handler_init();
  printf("[OK]\n\r");
  printf("initialize serial line...");
  serial_line_init();
  printf("[OK]\n\r");
  printf("initialize serial shell...");
  serial_shell_init();
  printf("[OK]\n\r");
  printf("initialize file shell...");
  shell_file_init();
  printf("[OK]\n\r");
  printf("register own shell commands...");
  commands_init();
  printf("[OK]\n\r");

  printf("initialize uSD card...");
	uSDcard_init();
  printf("[OK]\n\r");

  printf("initialize uarts test...");
  uarts_test_init();
  printf("[OK]\n\r");

  printf("load settings from sd card...");
  load_settings();
  printf("[OK]\n\r");

  //printf("initialize rime collect...");
  //collect_init();
  //printf("[OK]\n\r");

  // load settings from sd card

  

  
  printf("Boot succesfull.\n\r");  
  PROCESS_END();
}
