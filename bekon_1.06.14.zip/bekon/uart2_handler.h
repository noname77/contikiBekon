extern process_event_t UART2_SEND;

void uart2_handler_init();

PROCESS_NAME(uart2_process);
