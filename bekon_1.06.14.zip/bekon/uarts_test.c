#include <stdio.h>
#include "contiki.h"
#include "mc1322x.h"
#include "contiki-uart.h"
#include "dev/leds.h"
#include "uart2_handler.h"
#include "dev/serial-line.h"

#define FLASH_LED(l) {leds_on(l); clock_delay_msec(50); leds_off(l); clock_delay_msec(50);}

/*---------------------------------------------------------------------------*/
PROCESS(uarts_test, "UART2 TEST");
/*---------------------------------------------------------------------------*/

// tester thread
PROCESS_THREAD(uarts_test, ev, data)
{
  static struct etimer timer;
  static char msg[] = "Data\n";
  char* ptr = msg;
  PROCESS_BEGIN();


  while(1)
  {
    PROCESS_WAIT_EVENT();
/*
    etimer_set(&timer, 5*CLOCK_SECOND);
    
    if(ev == PROCESS_EVENT_TIMER)
    {
      printf("Posting stuff to uart2.\n\r");
      process_post(&uart2_process, UART2_SEND, ptr);
    }
*/
    if(ev == serial_line1_event_message)
      printf("UART1 received: %s\n\r", data);
    if(ev == serial_line2_event_message)
      printf("UART2 received: %s\n\r", data);
  }

  PROCESS_END();
}

void
uarts_test_init()
{
  process_start(&uarts_test, NULL);
}
