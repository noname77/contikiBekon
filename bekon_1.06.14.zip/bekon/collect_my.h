void collect_init();
void collect_exit();
