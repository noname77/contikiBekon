#include "loader/symbols.h"

extern const struct symbols symbols[1];
