void uarts_test_init();
