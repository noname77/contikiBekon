void multihop_init();
void multihop_exit();

PROCESS_NAME(multihop_process);

extern process_event_t mh_send;
